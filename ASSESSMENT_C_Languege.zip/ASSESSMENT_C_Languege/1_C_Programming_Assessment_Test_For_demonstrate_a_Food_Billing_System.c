/* 1. C Programming Assessment Test
� Write a program to demonstrate a Food Billing System.
� Display the Menu using appropriate codes.
� For Menu kinds of Programming , use the core logic of Loops/conditional statements.
� You need to strictly follow the syntaxes�s of that logic which you are using.
� Write the necessary comments for better understanding to you as well as to the faculty.

*** Adhere to the coding principles *** 
-> Execution Flow of the Project:

o First, display the food items available
o Then after the user can choose any of the item displayed
o Also take the quantity of selected food item by the customer, then ask the user that he/she wanna select more?
o If yes then again display the food items available and take an order from the customer. Here, you have to consider
     the total bill as the price of food items previously selected plus the price of new items added should display
	 as a whole bill.
o If no then display the final bill on the screen

Example of such system id given below : 

1. Pizza            price 180rs/pcs
2. Burger           price 100rs/pcs
3. Dosa             price = 120rs/pcs
4. Idli             price = 50rs/pcs
Please Enter your choose... :1

You have selected pizza.
Enter the quantity : 2
Amount: 360
Total Amount is = 360
Do you want place more orders ? y & n :y

Manu
1. Pizza            price = 180rs/pcs
2. Burger           price = 100rs/pcs
3. Dosa             price = 120rs/pcs
4.Idli              price = 50rs/pcs
Please Enter your choose... :2
You have selected Burger.
Enter the quantity : 2
Amount: 200
Total Amount is = 560
Do you want place more orders? y & n in
*/
#include <stdio.h>

main()
{
    int choice, quantity;
    char more;
    float totalAmount = 0.0, price;

    do // Display menu and handle user choices
	{
        printf("\n\t\t *** Menu ***\n\n");
        printf("\t 1. Pizza    -    180rs/pcs \n");
        printf("\t 2. Burger   -    100rs/pcs \n");
        printf("\t 3. Dosa     -    120rs/pcs \n");
        printf("\t 4. Idli     -    50rs/pcs \n");
        printf("\n\n\t --> Please enter your choice ( 1 - 4 ) : ");
        scanf("%d", &choice);

        switch (choice)         // Determine price based on user choice
		{
            case 1:
                price=180.0;
                printf("\n\t @ You have selected -->> PIZZA. \n");
                break;
            case 2:
                price=100.0;
                printf("\n\t @ You have selected -->> BURGER.\n");
                break;
            case 3:
                price=120.0;
                printf("\n\t @ You have selected -->> DOSA.\n");
                break;
            case 4:
                price=50.0;
                printf("\n\t @ You have selected -->> IDLI.\n");
                break;
            default:
                printf("\n\t >> Oops !!!! Invalid choice. !!! << \n\t Please select a valid item.\n");
                continue;
        }

        printf("\n-------------------------------------------------------\n");
        printf("\n\t Enter the quantity : ");         // quantity and calculate amount

        scanf("%d", &quantity);
        float amount=price*quantity;
        totalAmount+=amount;
        printf("\n-------------------------------------------------------\n");
        printf("\n\t -> Amount : %.f\n", amount);
        printf("\n\t -->> Total Amount is = %.f \n", totalAmount);

        printf("\n\n\t --> Do you want to place more orders? ( y / n ) : ");         // Ask from user for more orders
        scanf(" %c", &more);
    	printf("\n---------------------------------------------------\n----------------------------------------------------\n");

    } while (more == 'y' || more == 'Y');  // Continue if user inputs 'y' or 'n'

    printf("\n---------------------------------------------\n\n\t Final Bill : \n");     // Display final bill
    printf("\n---------------------------------------------\n\t --> Total Amount is = %.2f \n", totalAmount);
}
